/**
 * 익스프레스를 사용한 가장 단순한 샘플
 *
 */

// db 연결
const db = require("./db/db");

// Express 기본 모듈 불러오기
const { name } = require("ejs");
var express = require("express"),
  http = require("http");

// 익스프레스 객체 생성
var app = express();

const bodyParser = require("body-parser");

// 기본 포트를 app 객체에 속성으로 설정
app.set("port", process.env.PORT || 7878);

app.use(bodyParser.json());

// app.get("/", async (req, res, next) => {
//   try {
//     const post = await db.query("select * from test;");
//     console.log(post[0][0].name);
//   } catch (error) {
//     console.log("get error");
//   }
// });

app.get("/", async (req, res, next) => {
  try {
    const post = await db.query(
      "SELECT COUNT(trash_name) as '일반쓰레기' ,(SELECT COUNT(trash_name) FROM android.test WHERE trash_name = '종이쓰레기') as '종이쓰레기' ,(SELECT COUNT(trash_name) FROM android.test WHERE trash_name = '플라스틱') as '플라스틱' ,(SELECT COUNT(trash_name) FROM android.test WHERE trash_name = '고철') as '고철' ,(SELECT COUNT(trash_name) FROM android.test WHERE trash_name = '유리') as '유리' from android.test where trash_name = '일반쓰레기' ;"
    );
    // const post = await db.query(
    //   "select count(trash_name) as trash_name from android.test where trash_name = '일반쓰레기';"
    // );

    // res.send({ post: post[0][0].일반쓰레기 });

    // const post2 = {
    //   일반쓰레기: post[0][0].일반쓰레기,
    //   종이쓰레기: post[0][0].종이쓰레기,
    //   플라스틱: post[0][0].플라스틱,
    //   고철: post[0][0].고철,
    //   유리: post[0][0].유리,
    // };
    res.send({
      일반쓰레기: post[0][0].일반쓰레기,
      종이쓰레기: post[0][0].종이쓰레기,
      플라스틱: post[0][0].플라스틱,
      고철: post[0][0].고철,
      유리: post[0][0].유리,
    });

    // console.log(post.trash_name);
  } catch (error) {
    console.log("error");
  }
});

app.post("/", async (req, res, next) => {
  const text = await req.body.text;
  try {
    const query = await db.query("INSERT INTO test VALUES (?, ?)", [
      null,
      text,
    ]);

    res.send(text);
    console.log(text);
  } catch {
    console.log("error가 났지만 도착은 했습니다.");
  }
});

// Express 서버 시작
http.createServer(app).listen(app.get("port"), function () {
  console.log("익스프레스 서버를 시작했습니다 : " + app.get("port"));
});

module.exports = app;
